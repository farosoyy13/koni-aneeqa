/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        gold: {
          50: '#faf5e5',
          100: '#f5ebc6',
          200: '#ebd78d',
          300: '#e0c255',
          400: '#D4AF37',
          500: '#c9a227',
          600: '#a88616',
          700: '#866a10',
          800: '#654e0c',
          900: '#443308',
        },
      },
    },
  },
  plugins: [],
}
